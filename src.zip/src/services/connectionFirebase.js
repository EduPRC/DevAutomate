import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/database";
 
// Your web app's Firebase configuration
let firebaseConfig = {
    apiKey: "AIzaSyD4MuIupKNiC6jq__z31_gMfnYNVGQ2WUM",
    authDomain: "devautomate-45db2.firebaseapp.com",
    projectId: "devautomate-45db2",
    storageBucket: "devautomate-45db2.firebasestorage.app",
    messagingSenderId: "534490966963",
    appId: "1:534490966963:web:5eb242236839f33a9df9c6",
    baseUrl: "https://devautomate-45db2-default-rtdb.firebaseio.com/",
  };
 
// Initialize Firebase
if (!firebase.apps.length) {
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
}
export default firebase;